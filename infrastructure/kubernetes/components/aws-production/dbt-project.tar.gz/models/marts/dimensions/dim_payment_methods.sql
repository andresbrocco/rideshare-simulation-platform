{{
    config(
        materialized='table'
    )
}}

with rider_payment_changes as (
    select
        rider_id,
        payment_method_type,
        payment_method_masked,
        timestamp,
        -- Partition by (rider_id, payment_method_type) only — treating each change in
        -- masked card number as a new SCD record. Partitioning by masked number too
        -- would give each card its own independent chain, causing multiple "current"
        -- records per rider+type combination and duplicate joins in fact_payments.
        lead(timestamp) over (
            partition by rider_id, payment_method_type order by timestamp
        ) as next_timestamp
    from {{ ref('stg_riders') }}
),

with_validity as (
    select
        {{ dbt_utils.generate_surrogate_key(['rider_id', 'payment_method_type', 'payment_method_masked']) }} as payment_method_id,
        rider_id,
        payment_method_type,
        payment_method_masked,
        timestamp as valid_from,
        coalesce(next_timestamp, cast('9999-12-31 23:59:59' as timestamp)) as valid_to,
        case when next_timestamp is null then true else false end as current_flag
    from rider_payment_changes
),

final as (
    select
        {{ dbt_utils.generate_surrogate_key(['payment_method_id', 'valid_from']) }} as payment_method_key,
        payment_method_id,
        rider_id,
        payment_method_type,
        payment_method_masked,
        valid_from,
        valid_to,
        current_flag
    from with_validity
)

select * from final
